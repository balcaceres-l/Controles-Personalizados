
/*
Author Balcaceres
*/
package Clases;
import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;
import java.awt.*;
import java.util.Vector;

public class tablaCustom extends JPanel {

    private JTable table;
    private JTextField searchField;
    private DefaultTableModel tableModel;
    private TableRowSorter<TableModel> rowSorter;
    private String[] columnNames; 
    public tablaCustom() {
        setLayout(new BorderLayout());
        tableModel = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; 
            }
        };
        
        table = new JTable(tableModel);
        table.setFillsViewportHeight(true);

        searchField = new JTextField("Buscar...");
        searchField.setForeground(Color.GRAY);
        searchField.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                applyFilter();
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                applyFilter();
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                applyFilter();
            }
        });
        searchField.addFocusListener(new java.awt.event.FocusAdapter() {
            @Override
            public void focusGained(java.awt.event.FocusEvent e) {
                if (searchField.getText().equals("Buscar...")) {
                    searchField.setText("");
                    searchField.setForeground(Color.BLACK);
                }
            }
            @Override
            public void focusLost(java.awt.event.FocusEvent e) {
                if (searchField.getText().isEmpty()) {
                    searchField.setText("Buscar...");
                    searchField.setForeground(Color.GRAY);
                }
            }
        });


        rowSorter = new TableRowSorter<>(table.getModel());
        table.setRowSorter(rowSorter);

        add(searchField, BorderLayout.NORTH);
        add(new JScrollPane(table), BorderLayout.CENTER);
    }


    private void applyFilter() {
        String filterText = searchField.getText();
        if (filterText.trim().length() == 0 || filterText.equals("Buscar...")) {
            rowSorter.setRowFilter(null);
        } else {
            rowSorter.setRowFilter(RowFilter.regexFilter("(?i)" + filterText));
        }
    }
    public String[] getColumnNames() {
        return columnNames;
    }

    public void setColumnNames(String[] columnNames) {
        this.columnNames = columnNames;
        tableModel.setColumnIdentifiers(columnNames); 
    }

    public void addRow(Vector<Object> rowData) {
        tableModel.addRow(rowData);
    }
    public void clearTable() {
        tableModel.setRowCount(0);
    }
}

