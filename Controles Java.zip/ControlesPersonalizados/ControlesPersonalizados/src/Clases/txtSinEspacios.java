/*
Author Balcaceres
*/
package Clases;

import javax.swing.JTextField;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.SwingUtilities;

public class txtSinEspacios extends JTextField {
    
    public txtSinEspacios(){
        super();
        agregarValidacion();
    }
    
    public void agregarValidacion(){
        this.getDocument().addDocumentListener(new DocumentListener(){
            @Override
            public void insertUpdate(DocumentEvent e) {
                validarTexto();
                            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                validarTexto();
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                validarTexto();
            }
            
        });
    }
    public void validarTexto(){
        SwingUtilities.invokeLater(()->{
        String texto = getText();
        if (texto.contains(" ")){
            setText(texto.replace(" ",""));
        }
    });
    }
}

