/*
Author Balcaceres
*/
package Clases;
import java.awt.Color;
import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class txtCorreo extends JTextField{
    
    private String placeholderText = "Ingrese su correo";
    private final List<String> commonDomains = Arrays.asList("gmail.com", "yahoo.com", "hotmail.com");
    private JPopupMenu suggestionPopup;
    private JList<String> suggestionList;

    public txtCorreo() {
        super();
        setupPlaceholder();
        setupAutocomplete();
    }

    private void setupPlaceholder() {
        this.setText(placeholderText);
        this.setForeground(Color.GRAY);

        this.addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent e) {
                if (getText().equals(placeholderText)) {
                    setText("");
                    setForeground(Color.BLACK);
                }
            }

            @Override
            public void focusLost(FocusEvent e) {
                if (getText().isEmpty()) {
                    setText(placeholderText);
                    setForeground(Color.GRAY);
                }
            }
        });
    }

    private void setupAutocomplete() {
        suggestionPopup = new JPopupMenu();
        suggestionList = new JList<>();
        suggestionList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        suggestionPopup.add(new JScrollPane(suggestionList));

        this.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                showSuggestions();
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                showSuggestions();
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                showSuggestions();
            }
        });

        suggestionList.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                selectSuggestion();
            }
        });

        this.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER && suggestionPopup.isVisible()) {
                    selectSuggestion();
                }
            }
        });
    }

    private void showSuggestions() {
        String text = getText();
        if (text.contains("@")) {
            String prefix = text.substring(0, text.indexOf("@") + 1);
            List<String> filteredSuggestions = new ArrayList<>();
            for (String domain : commonDomains) {
                if ((prefix + domain).startsWith(text)) {
                    filteredSuggestions.add(prefix + domain);
                }
            }

            if (!filteredSuggestions.isEmpty()) {
                suggestionList.setListData(filteredSuggestions.toArray(new String[0]));
                suggestionPopup.show(this, 0, this.getHeight());
            } else {
                suggestionPopup.setVisible(false);
            }
        } else {
            suggestionPopup.setVisible(false);
        }
    }

    private void selectSuggestion() {
        String selectedValue = suggestionList.getSelectedValue();
        if (selectedValue != null) {
            setText(selectedValue);
        }
        suggestionPopup.setVisible(false);
    }
    
    public String getPlaceholderText() {
        return placeholderText;
    }

    public void setPlaceholderText(String placeholderText) {
        this.placeholderText = placeholderText;
        if (getText().isEmpty()) {
            setText(placeholderText);
            setForeground(Color.GRAY);
        }
    }
}
