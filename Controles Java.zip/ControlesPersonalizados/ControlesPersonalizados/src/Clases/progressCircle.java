
/*
Author Balcaceres
*/
package Clases;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import javax.swing.JProgressBar;
public class progressCircle extends JProgressBar {
    
    public progressCircle() {
        initialize();
    }

    // Método de inicialización que contiene la lógica del constructor original
    private void initialize() {
        setMinimum(0);
        setMaximum(100);
        setPreferredSize(new Dimension(100, 100));
        setStringPainted(true);
    }

    // Constructor con parámetros que llama al método de inicialización
    public void setRange(int min, int max) {
        setMinimum(min);
        setMaximum(max);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g.create();
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        int diameter = Math.min(getWidth(), getHeight()) - 10;
        int x = (getWidth() - diameter) / 2;
        int y = (getHeight() - diameter) / 2;

        // Dibujar el fondo del círculo
        g2d.setColor(Color.LIGHT_GRAY);
        g2d.fillOval(x, y, diameter, diameter);

        // Calcular el ángulo del progreso
        int angle = (int) (360 * getPercentComplete());

        // Dibujar el progreso
        g2d.setColor(Color.BLUE);
        g2d.fillArc(x, y, diameter, diameter, 90, -angle);

        // Dibujar el porcentaje en el centro
        String progressText = getString();
        FontMetrics fm = g2d.getFontMetrics();
        int textWidth = fm.stringWidth(progressText);
        int textHeight = fm.getAscent();
        g2d.setColor(Color.BLACK);
        g2d.drawString(progressText, getWidth() / 2 - textWidth / 2, getHeight() / 2 + textHeight / 4);

        g2d.dispose();
    }
}
