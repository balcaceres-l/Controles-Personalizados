/*
Author Balcaceres
*/
package Clases;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
public class txtSoloLetras extends JTextField {
     public txtSoloLetras() {
        super();
        agregarValidacion();
    }

    private void agregarValidacion() {
        this.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                validarTexto();
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                validarTexto();
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                validarTexto();
            }
        });
    }

    private void validarTexto() {
        SwingUtilities.invokeLater(() -> {
            String texto = getText();
            if (!texto.matches("[a-zA-Z\s]*")) {  
                setText(texto.replaceAll("[^a-zA-Z\s]", "")); 
            }
        });
    }

}
